package com.demo.spring;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.demo.spring.entity.Emp;



@RestController
public class HrRestController {
	
	
	@Autowired
	RestTemplate  rt;
	
	@GetMapping(path="/hr/get" ,produces="application/json")
	public ResponseEntity  getEmpInfoById(@RequestParam("eid") int id)
	{
		HttpHeaders hd = new HttpHeaders();
		hd.set("ACCEPT", MediaType.APPLICATION_JSON_VALUE);
		HttpEntity req = new HttpEntity<Object>(hd);
		ResponseEntity<String> res = rt.exchange("http://localhost:18080/emp/find/"+id, HttpMethod.GET, req,
				String.class);

		return res;
	}
	
	@PostMapping(path="/hr/save",produces=MediaType.APPLICATION_JSON_VALUE,consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity  registerEmployee(@RequestBody Emp e)
	{
		HttpHeaders hd = new HttpHeaders();
		hd.set("ACCEPT", MediaType.APPLICATION_JSON_VALUE);
		hd.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
		HttpEntity req = new HttpEntity<Object>(e,hd);
		
		
		ResponseEntity<String> res = rt.exchange("http://localhost:18080/emp/save", 
				HttpMethod.POST, req,
				String.class);

		return res;
	}
	
	
	@GetMapping(path="/hr/emplist" ,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity  getEmpList()
	{
		HttpHeaders hd = new HttpHeaders();
		hd.set("ACCEPT", MediaType.APPLICATION_JSON_VALUE);
		HttpEntity req = new HttpEntity<Object>(hd);
				
		
		ResponseEntity<List<Emp>> res = rt.exchange("http://localhost:18080/emp/list", HttpMethod.GET, req,
				new ParameterizedTypeReference<List<Emp>>() {
				});
	
		return res;
	}

}
