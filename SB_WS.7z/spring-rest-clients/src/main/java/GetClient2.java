import java.util.List;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.demo.spring.entity.Emp;

public class GetClient2 {

	public static void main(String[] args) {
		RestTemplate rt = new RestTemplate();
		HttpHeaders hd = new HttpHeaders();
		hd.set("ACCEPT", MediaType.APPLICATION_JSON_VALUE);
		HttpEntity req = new HttpEntity<Object>(hd);
		ResponseEntity<Emp> res = rt.exchange("http://localhost:18080/emp/find/104", HttpMethod.GET, req,
				Emp.class);

		System.out.println(res.getBody().getName());
		
		
		ResponseEntity<List<Emp>> res2 = rt.exchange("http://localhost:18080/emp/list", HttpMethod.GET, req,
				new ParameterizedTypeReference<List<Emp>>() {
				});

		for(Emp e:res2.getBody())
		{
			System.out.println(e.getName());
		}
		
		
		
		
	}

}
