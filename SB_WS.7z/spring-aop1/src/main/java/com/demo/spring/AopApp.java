package com.demo.spring;

import java.lang.reflect.Method;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.demo.spring.aop.Performer;

public class AopApp {

	public static void main(String[] args) {
		ApplicationContext ctx=new AnnotationConfigApplicationContext(AopConfig.class);
		
		Performer pf=(Performer)ctx.getBean("singer");
		
		pf.perform();

		System.out.println(pf.getClass().getName());
		
		Method[] methods=pf.getClass().getMethods();
		
		for(Method m:methods)
		{
			System.out.println("method names"+m);
		}
	}

}
