package com.demo.spring.aop;

import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class Audience  {
	
	//@Pointcut("execution(* com.demo.spring.aop.Performer.perform(..))")
	@Pointcut("execution(* com..Perf*.perform(..))")
	private void pcut() {}

	@Before("pcut()")
	public void switchOfMobile()  {
		
		System.out.println("Switch off your mobile");

	}

	@Before("pcut()")
	public void takeSeat() {
		//throw new RuntimeException("Why be seated");
		System.out.println("Please be Seated");

	}
	
	@AfterReturning("pcut()")
	public void applaud() {
		System.out.println("Very good Singer...... clap !!");

	}

}
