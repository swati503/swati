package com.demo.spring.aop;

public interface Performer {

	public void perform();
}
