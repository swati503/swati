package com.demo.spring.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.demo.spring.entity.Emp;


//for jdbc we can use CrudRepository
public interface EmpRepository extends JpaRepository<Emp, Integer> {
	
	@Query(name ="q1",value="select a from Emp a where a.salary between ?1 and ?2")
	public List<Emp> getEmpSalMoreThan50k(double sal1,double sal2);

}
