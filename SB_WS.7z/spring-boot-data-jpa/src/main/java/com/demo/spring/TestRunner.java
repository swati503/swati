package com.demo.spring;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.demo.spring.entity.Emp;
import com.demo.spring.service.HrService;


@Component
public class TestRunner implements CommandLineRunner{

	@Autowired
	HrService service;
	@Override
	public void run(String... args) throws Exception {
		System.out.println("This to test  Boot");
		//System.out.println(service.registerEmployee(117, "PINKY", "kolkata", 10000.00));
		/*List<Emp> emplist=service.getAllEMP();
		for(Emp e:emplist)
		{
		System.out.println(e.getName());
		}*/
		
		//System.out.println(service.findEmp(112));
		
		service.printwithSal(32000, 70000);
		
	}

}
