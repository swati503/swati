package com.demo.spring.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.spring.dao.EmpRepository;
import com.demo.spring.entity.Emp;


@Service
@Transactional
public class HrService {

	@Autowired
	private EmpRepository dao;
	
	
	

/*
	public String registerEmployee(int id,String name,String city,double sal)
	{
		String res=dao.saveEmp(new Emp(id, name, city, sal));
		
		return res;
	}*/
	
	
	public List<Emp> getAllEMP()
	{
		List<Emp> empList=dao.findAll();
		
		return empList;
	}
	
	
	public String findEmp(int id)
	{
		Optional <Emp> o=dao.findById(id);
		if(o.isPresent())
		{
			Emp e=o.get();
		return e.getEmpid()+" "+e.getName()+" "+e.getCity();
		}
		else
			return "NO EMP ";
		
		
	}
	
	public void printwithSal(double sal1,double sal2)
	{
		for(Emp e :dao.getEmpSalMoreThan50k(sal1, sal2))
		{
			System.out.println(e.getName()+" "+e.getSalary());
		}
	}
}
