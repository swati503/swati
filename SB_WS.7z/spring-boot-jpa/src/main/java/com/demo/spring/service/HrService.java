package com.demo.spring.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.demo.spring.dao.EmpDao;
import com.demo.spring.entity.Emp;


@Service
@Transactional
public class HrService {

	@Autowired
	@Qualifier("empDaoJPAImpl")
	private EmpDao dao;
	
	
	


	public String registerEmployee(int id,String name,String city,double sal)
	{
		String res=dao.saveEmp(new Emp(id, name, city, sal));
		
		return res;
	}
	
	
	public List<Emp> getAllEMP()
	{
		List<Emp> empList=dao.getAll();
		
		return empList;
	}
	
	
	public String findEmp(int id)
	{
		Emp emp=dao.findById(id);
		if(emp == null)		
			return "NO Emp found";		
		else 		
		return emp.getEmpid()+" "+emp.getName();
	}
}
