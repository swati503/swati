package com.demo.spring;

import org.apache.logging.log4j.core.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.spring.service.HRService;

public class App1 {

	public static void main(String[] args) {
	
		ApplicationContext ctx = new ClassPathXmlApplicationContext("context.xml");
		
		
		HRService hr=(HRService)ctx.getBean("hr");
		System.out.println("Mail message DI ==>"+hr.registerEmployee(100, "Swati", "Pune", 100));
		
	
	}

}
