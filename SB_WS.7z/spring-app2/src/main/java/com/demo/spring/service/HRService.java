package com.demo.spring.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.demo.spring.dao.EmpDao;
import com.demo.spring.entity.Emp;

public class HRService {

	
	private EmpDao dao;
	
	
	public void setDao(EmpDao dao) {
		this.dao = dao;
	}


	public String registerEmployee(int id,String name,String city,double sal)
	{
		String res=dao.saveEmp(new Emp(id, name, city, sal));
		
		return res;
	}
}
