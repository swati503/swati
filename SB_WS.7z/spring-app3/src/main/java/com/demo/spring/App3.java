package com.demo.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.demo.spring.service.HrService;

public class App3 {

	public static void main(String[] args) {
	
		ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);		
		
		HrService hr=(HrService)ctx.getBean("hrService");
		System.out.println("Mail message DI ==>"+hr.registerEmployee(100, "Swati", "Pune", 100));
		
	
	}

}
