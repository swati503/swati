package com.demo.spring.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.demo.spring.entity.Emp;

@Repository
public class EmpDaoImpl implements EmpDao {
	@Autowired
	private JdbcTemplate jt;

	@Override
	public String saveEmp(Emp e) {
       String insert_query="insert  into  EMP (empno,name,address,salary) values (?,?,?,?)";
     int count=  jt.update(new PreparedStatementCreator() {
		
		@Override
		public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
			PreparedStatement pst=con.prepareStatement(insert_query);
			pst.setInt(1, e.getEmpid());
			pst.setString(2, e.getName());
			pst.setString(3,e.getCity());
			pst.setDouble(4, e.getSalary());
			return pst;
		}
	});
       
       if(count == 1)
       
    	   return "Emp Saved";
    	   else
    		   return "Emp Not Saved";
		
	}

	@Override
	public Emp findById(int id) {
		Emp emp=null;
		try
		{
		emp=jt.queryForObject("Select * from emp where empno="+id,new RowMapper<Emp>() {

			@Override
			public Emp mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				return new Emp(rs.getInt("EMPNO"),rs.getString("NAME"),rs.getString("ADDRESS"),rs.getDouble("SALARY"));
			}
			
		});
		
		return emp;
		}catch(Exception ex)
		{
			ex.printStackTrace();
			emp=null;
		}
		return emp;
	}

	@Override
	public List<Emp> getAll() {
		List<Emp> empList=jt.query("Select * from emp",new RowMapper<Emp>() {

			@Override
			public Emp mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				return new Emp(rs.getInt("EMPNO"),rs.getString("NAME"),rs.getString("ADDRESS"),rs.getDouble("SALARY"));
			}
			
		});
		
		return empList;
	}

	@Override
	public String delete(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
