package com.demo.movie;

public interface MovieDao{
	
	Movie findByDirector(String name);
	
}